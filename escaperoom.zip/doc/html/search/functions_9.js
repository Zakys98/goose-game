var searchData=
[
  ['set_5fadd_328',['set_add',['../set_8h.html#ab3544eb79268ce0d2bade4a4878a3e77',1,'set_add(Set *s, Id id):&#160;set.c'],['../set_8c.html#ab3544eb79268ce0d2bade4a4878a3e77',1,'set_add(Set *s, Id id):&#160;set.c']]],
  ['set_5fcreate_329',['set_create',['../set_8h.html#abcc73b7ad3913fc92dd95d366c9c8687',1,'set_create():&#160;set.c'],['../set_8c.html#abcc73b7ad3913fc92dd95d366c9c8687',1,'set_create():&#160;set.c']]],
  ['set_5fdelete_330',['set_delete',['../set_8h.html#a37062cae6eab5e8264a04f7d710b5fa9',1,'set_delete(Set *s, Id id):&#160;set.c'],['../set_8c.html#a37062cae6eab5e8264a04f7d710b5fa9',1,'set_delete(Set *s, Id id):&#160;set.c']]],
  ['set_5fdestroy_331',['set_destroy',['../set_8h.html#a3a31cd2ae010c3b76ce60655c9d4f009',1,'set_destroy(Set **s):&#160;set.c'],['../set_8c.html#a3a31cd2ae010c3b76ce60655c9d4f009',1,'set_destroy(Set **s):&#160;set.c']]],
  ['set_5felement_5fexists_332',['set_element_exists',['../set_8c.html#ad29c89174d50fdb93ddfdc2098df7705',1,'set.c']]],
  ['set_5fget_5felement_5fby_5fid_333',['set_get_element_by_id',['../set_8c.html#a6a1f10ad5d1768202cda6b5782211f4b',1,'set.c']]],
  ['set_5fget_5felements_334',['set_get_elements',['../set_8h.html#ae1d957ce6e1b1f3ce05054968fe36afd',1,'set_get_elements(Set *s):&#160;set.c'],['../set_8c.html#ae1d957ce6e1b1f3ce05054968fe36afd',1,'set_get_elements(Set *s):&#160;set.c']]],
  ['set_5fget_5fsize_335',['set_get_size',['../set_8h.html#a8d52f93e9e5f8d44abfa5e3557de3ac1',1,'set_get_size(Set *s):&#160;set.c'],['../set_8c.html#a8d52f93e9e5f8d44abfa5e3557de3ac1',1,'set_get_size(Set *s):&#160;set.c']]],
  ['set_5fis_5fempty_336',['set_is_empty',['../set_8h.html#acb8ec28ba1f3e490005c35f0d4230a40',1,'set_is_empty(Set *s):&#160;set.c'],['../set_8c.html#acb8ec28ba1f3e490005c35f0d4230a40',1,'set_is_empty(Set *s):&#160;set.c']]],
  ['set_5fprint_337',['set_print',['../set_8h.html#ab67ec10e904487a74411d94fe40b4943',1,'set_print(Set *s, FILE *fp):&#160;set.c'],['../set_8c.html#ab67ec10e904487a74411d94fe40b4943',1,'set_print(Set *s, FILE *fp):&#160;set.c']]]
];
