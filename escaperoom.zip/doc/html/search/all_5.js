var searchData=
[
  ['link_2ec_92',['link.c',['../link_8c.html',1,'']]],
  ['link_2eh_93',['link.h',['../link_8h.html',1,'']]],
  ['link_5fcreate_94',['link_create',['../link_8h.html#aaf21d03943afcbed370ca720f972482c',1,'link_create():&#160;link.c'],['../link_8c.html#aaf21d03943afcbed370ca720f972482c',1,'link_create():&#160;link.c']]],
  ['link_5fdestroy_95',['link_destroy',['../link_8h.html#a5f4eb06e0f94395dcfbce5b57fa11bbd',1,'link_destroy(Link **):&#160;link.c'],['../link_8c.html#aa27f73fc1e4909140b91373dce693370',1,'link_destroy(Link **l):&#160;link.c']]],
  ['link_5fget_5ffirst_5fspace_96',['link_get_first_space',['../link_8h.html#a3c93991312c578aecf6fb1cb3481b073',1,'link_get_first_space(Link *l):&#160;link.c'],['../link_8c.html#a3c93991312c578aecf6fb1cb3481b073',1,'link_get_first_space(Link *l):&#160;link.c']]],
  ['link_5fget_5fid_97',['link_get_id',['../link_8h.html#ab1f9ab65f3b10bcf29c95cefdefc95a2',1,'link_get_id(Link *l):&#160;link.c'],['../link_8c.html#ab1f9ab65f3b10bcf29c95cefdefc95a2',1,'link_get_id(Link *l):&#160;link.c']]],
  ['link_5fget_5fname_98',['link_get_name',['../link_8h.html#a18db4a32fdbade7c848fc18aaff476e7',1,'link_get_name(Link *l):&#160;link.c'],['../link_8c.html#a18db4a32fdbade7c848fc18aaff476e7',1,'link_get_name(Link *l):&#160;link.c']]],
  ['link_5fget_5fopened_99',['link_get_opened',['../link_8h.html#a8f28bccacb97f83b633bd3b68bbeb64f',1,'link_get_opened(Link *l):&#160;link.c'],['../link_8c.html#a8f28bccacb97f83b633bd3b68bbeb64f',1,'link_get_opened(Link *l):&#160;link.c']]],
  ['link_5fget_5fsecond_5fspace_100',['link_get_second_space',['../link_8h.html#ac780a41fe029037e6458c70c29ee7b68',1,'link_get_second_space(Link *l):&#160;link.c'],['../link_8c.html#ac780a41fe029037e6458c70c29ee7b68',1,'link_get_second_space(Link *l):&#160;link.c']]],
  ['link_5fprint_101',['link_print',['../link_8h.html#a3f3be00a94f98529c80a02bb0c8b9879',1,'link_print(Link *l):&#160;link.c'],['../link_8c.html#a3f3be00a94f98529c80a02bb0c8b9879',1,'link_print(Link *l):&#160;link.c']]],
  ['link_5fset_5ffirst_5fspace_102',['link_set_first_space',['../link_8h.html#ac2149d88d44428c5223795b942fac1ed',1,'link_set_first_space(Link *l, Id id):&#160;link.c'],['../link_8c.html#ac2149d88d44428c5223795b942fac1ed',1,'link_set_first_space(Link *l, Id id):&#160;link.c']]],
  ['link_5fset_5fid_103',['link_set_id',['../link_8h.html#aa90399681692e2b062eb72328dafac94',1,'link_set_id(Link *l, Id id):&#160;link.c'],['../link_8c.html#aa90399681692e2b062eb72328dafac94',1,'link_set_id(Link *l, Id id):&#160;link.c']]],
  ['link_5fset_5fname_104',['link_set_name',['../link_8h.html#ae3d998c5966226b44162967adf356ac9',1,'link_set_name(Link *l, char *name):&#160;link.c'],['../link_8c.html#ae3d998c5966226b44162967adf356ac9',1,'link_set_name(Link *l, char *name):&#160;link.c']]],
  ['link_5fset_5fopened_105',['link_set_opened',['../link_8h.html#a1474d8263a28e3c9fc10f068ea1c92b5',1,'link_set_opened(Link *l, BOOL opened):&#160;link.c'],['../link_8c.html#a1474d8263a28e3c9fc10f068ea1c92b5',1,'link_set_opened(Link *l, BOOL opened):&#160;link.c']]],
  ['link_5fset_5fsecond_5fspace_106',['link_set_second_space',['../link_8h.html#a8c7ba74d26209c7db3208ecd015667b9',1,'link_set_second_space(Link *l, Id id):&#160;link.c'],['../link_8c.html#a8c7ba74d26209c7db3208ecd015667b9',1,'link_set_second_space(Link *l, Id id):&#160;link.c']]],
  ['link_5ftest_2ec_107',['link_test.c',['../link__test_8c.html',1,'']]]
];
